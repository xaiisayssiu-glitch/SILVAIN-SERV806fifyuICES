# Silvain Studio — Exact Original Design

This package contains the exact production build of the Silvain Studio website. It preserves the original espresso background, orbit/ring visuals, compiled typography, department pages, pricing, search, responsive navigation, mobile menu, sticky Contact Us action, hover interactions, and enquiry form.

## Deploy the website

Unzip this package and open the `site` folder. Upload the **contents of `site`**, not the ZIP file itself, to your host.

| Host | Configuration |
|---|---|
| Netlify | Drag the contents of `site` into Netlify Drop. The included `_redirects` file keeps `/enquire` and `/department/...` routes working. |
| Vercel | Import a repository containing the contents of `site`, choose **Other**, leave Build Command empty, set Output Directory to `.`, and deploy. The included `vercel.json` rewrites client-side routes to `index.html`. |

For the exact original design and working buttons, deploy the `site` folder. Do not upload a single standalone HTML file; the website uses the compiled JavaScript and CSS assets in `site/assets`.

## Test after deployment

Open the home page, click Enquire, click a department row, refresh a department URL, type `seo` into service search, open the mobile menu, and test the sticky Contact Us button. The enquiry form uses FormSubmit and may require a one-time activation email to `SilvainStudio@protonmail.com`.
